# Cosmologia

Esta seção descreve a origem, os planos existenciais e as forças cósmicas do universo Starblaze.