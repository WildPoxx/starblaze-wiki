# História

Aqui se encontram os principais eventos, eras e linhagens que moldaram o mundo de Starblaze.