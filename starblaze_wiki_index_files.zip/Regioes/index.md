# Regiões

Descrição geográfica e política das principais regiões do cenário.