# Facções

Religiões, ordens, guildas e instituições que influenciam a estrutura social.