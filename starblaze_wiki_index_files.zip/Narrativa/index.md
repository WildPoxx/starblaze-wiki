# Narrativa

Contos, ganchos, missões e ambiguidades interpretativas.